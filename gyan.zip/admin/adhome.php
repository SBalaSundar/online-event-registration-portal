<?php
session_start();
if(!$_SESSION['aid']){
	echo "<script>alert('Un Authorized Access'); window.location.href='index.php';</script>";
}
else{
include 'connection.php';
?> 
<head>
<script src='//static.codepen.io/assets/editor/live/console_runner-1df7d3399bdc1f40995a35209755dcfd8c7547da127f6469fd81e5fba982f6af.js'></script>
<script src='//static.codepen.io/assets/editor/live/css_reload-5619dc0905a68b2e6298901de54f73cefe4e079f65a75406858d92924b4938bf.js'></script>
<style class="cp-pen-styles">@import url('https://fonts.googleapis.com/css?family=Amarante');


html { overflow-y: scroll; }
body { 
  background: #eee url('https://i.imgur.com/eeQeRmk.png'); /* https://subtlepatterns.com/weave/ */
  font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
  font-size: 70%;
  line-height: 1;
  color: #585858;
  padding: 22px 10px;
  padding-bottom: 55px;
}

::selection { background: #5f74a0; color: #fff; }
::-moz-selection { background: #5f74a0; color: #fff; }
::-webkit-selection { background: #5f74a0; color: #fff; }

br { display: block; line-height: 1.6em; } 

article, aside, details, figcaption, figure, footer, header, hgroup, menu, nav, section { display: block; }
ol, ul { list-style: none; }

input, textarea { 
  -webkit-font-smoothing: antialiased;
  -webkit-text-size-adjust: 100%;
  -ms-text-size-adjust: 100%;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  outline: none; 
}

blockquote, q { quotes: none; }
blockquote:before, blockquote:after, q:before, q:after { content: ''; content: none; }
strong, b { font-weight: bold; } 

table { border-collapse: collapse; border-spacing: 0; }
img { border: 0; max-width: 100%; }

h1 { 
  font-family: 'Amarante', Tahoma, sans-serif;
  font-weight: bold;
  font-size: 3.6em;
  line-height: 1.7em;
  margin-bottom: 10px;
  text-align: center;
}


/** page structure **/
#wrapper {
  display: block;
  width: 850px;
  background: #fff;
  margin: 0 auto;
  padding: 10px 17px;
  -webkit-box-shadow: 2px 2px 3px -1px rgba(0,0,0,0.35);
}

#keywords {
  margin: 0 auto;
  font-size: 1.2em;
  margin-bottom: 15px;
}


#keywords thead {
  cursor: pointer;
  background: #c9dff0;
}
#keywords thead tr th { 
  font-weight: bold;
  padding: 10px 10px;
  padding-left: 10px;
}
#keywords thead tr th span { 
  padding-right: 20px;
  background-repeat: no-repeat;
  background-position: 100% 100%;
}

#keywords thead tr th.headerSortUp, #keywords thead tr th.headerSortDown {
  background: #acc8dd;
}

#keywords thead tr th.headerSortUp span {
  background-image: url('https://i.imgur.com/SP99ZPJ.png');
}
#keywords thead tr th.headerSortDown span {
  background-image: url('https://i.imgur.com/RkA9MBo.png');
}


#keywords tbody tr { 
  color: #555;
}
#keywords tbody tr td {
  text-align: center;
  padding: 15px 10px;
}
#keywords tbody tr td.lalign {
  text-align: left;
}</style>
</head>
<body bgcolor="aabbcc">
<p><h3>Admin Home Page</h3>
<a href="attendance.php">Attendance</a></p>
<form method="POST">
<!--<select name="viewcategory">
<option value="All">No Filters(Display all)</option>
<option value="dept">Department</option>
<option value="event">Event</option>
<option value="year">Year</option>
<option value="attendance">Presence</option>
<option value="lop">Level of Participation</option>
</select> !-->
	<p align="center"><label for="dept">Department</label>
		<select name="dept" onchange="showDept(this.value)">
			<option value="NULL">Select Category</option>
			<option value="CSE">CSE</option>
			<option value="IT">IT</option>
		</select>
	<label for="Event">Event</label>
		<select name="event">
			<option value="NULL">Select Category</option>
			<option value="Poster Designing">Poster Designing</option>
			<option value="Web Designing">Web Designing</option>
			<option value="Online Coding">Online Coding</option>
			<option value="DB Mania">DB Mania</option>
		</select>
		<label for="year">Year</label>
		<select name="year">
			<option value="NULL">Select Category</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
		</select>
		<label for="presence">Presence</label>
		<select name="presence">
			<option value="NULL">Select Category</option>
			<option value="P">Present</option>
			<option value="AB">Absent</option>
		</select>
		<label for="lop">LOP</label>
		<select name="lop">
			<option value="NULL">Select Category</option>
			<option value="participated">Participants</option>
			<option value="winners">Winners</option>
		</select>
		<button type="submit" name="search"><b>Search</b></button></P>
<div id="txtHint"><p></P>
				</div>
	<table id="keywords" cellspacing="0" cellpadding="0" border="2">
	<thead>
		<th>S.No</th>
		<th>Ad_no</th>
		<th>Name</th>
		<th>Rollno</th>
		<th>Dept</th>
		<th>Year</th>
		<th>Poster Designing</th>
		<th>Presence</th>
		<th>Web Designing</th>
		<th>Presence</th>
		<th>Online Coding</th>
		<th>Presence</th>
		<th>DB Mania</th>
		<th>Presence</th>
		<th>LOP</th>
	</thead>
	<tbody>
<?php if(isset($_POST['search'])){ 
	$dept=$_POST['dept'];
	$event=$_POST['event'];
	$year = $_POST['year'];
	$presence = $_POST['presence'];
	$lop = $_POST['lop'];
	$event_no="";
	if($dept=="NULL" and $event=="NULL" and $year=="NULL" and $presence=="NULL" and $lop=="NULL"){
	$sql = "select * from participants";
	}
	else{
		if($event=="Poster Designing"){$event_no="event_1";}
		elseif($event=="Web Designing"){$event_no="event_2";}
		elseif($event=="Online Coding"){$event_no="event_3";}
		elseif($event=="DB Mania"){$event_no="event_4";}
		if($event_no=='event_1'){$att = 'attendance';}
		elseif($event_no=='event_2'){$att = 'att_2';}
		elseif($event_no=='event_3'){$att = 'att_3';}
		elseif($event_no=='event_4'){$att = 'att_4';}
	}
	if($dept!="NULL" and $event=="NULL" and $year=="NULL" and $presence=="NULL" and $lop=="NULL"){
		$sql = "select * from participants where dept='".$dept."'";
	}
	elseif($dept=="NULL" and $event!="NULL" and $year=="NULL" and $presence=="NULL" and $lop=="NULL"){
		$sql = "select * from participants where ".$event_no."='".$event."'";
	}
	elseif($dept=="NULL" and $event=="NULL" and $year!="NULL" and $presence=="NULL" and $lop=="NULL"){
		$sql = "select * from participants where `year`='".$year."'";
	}
	elseif($dept=="NULL" and $event=="NULL" and $year=="NULL" and $presence!="NULL" and $lop=="NULL"){
		$sql = "select * from participants where attendance='".$presence."'";
	}
	elseif($dept=="NULL" and $event=="NULL" and $year=="NULL" and $presence=="NULL" and $lop!="NULL"){
		$sql = "select * from participants where lop='".$lop."'";
	}
	elseif($dept!="NULL" and $event!="NULL" and $year=="NULL" and $presence=="NULL" and $lop=="NULL"){
		$sql = "select * from participants where dept='".$dept."' and ".$event_no."='".$event."'";
	}
	elseif($dept!="NULL" and $event=="NULL" and $year!="NULL" and $presence=="NULL" and $lop=="NULL"){
		$sql = "select * from participants where dept='".$dept."' and `year`='".$year."'";
	}
	elseif($dept!="NULL" and $event=="NULL" and $year=="NULL" and $presence!="NULL" and $lop=="NULL"){
		$sql = "select * from participants where dept='".$dept."' and attendance='".$presence."'";
	}
	elseif($dept!="NULL" and $event=="NULL" and $year=="NULL" and $presence=="NULL" and $lop!="NULL"){
		$sql = "select * from participants where dept='".$dept."' and lop='".$lop."'";
	}
	elseif($dept=="NULL" and $event!="NULL" and $year!="NULL" and $presence=="NULL" and $lop=="NULL"){
		$sql = "select * from participants where ".$event_no."='".$event."' and `year`='".$year."'";
	}
	elseif($dept=="NULL" and $event!="NULL" and $year=="NULL" and $presence!="NULL" and $lop=="NULL"){
		$sql = "select * from participants where ".$att."='".$presence."'";
	}
	elseif($dept=="NULL" and $event!="NULL" and $year=="NULL" and $presence=="NULL" and $lop!="NULL"){
		$sql = "select * from participants where ".$event_no."='".$event."' and lop='".$lop."'";
	}
	elseif($dept!="NULL" and $event!="NULL" and $year!="NULL" and $presence!="NULL" and $lop!="NULL"){
		$sql = "select * from participants where dept='".$dept."' and ".$event_no."='".$event."' and `year`='".$year."' and attendance='".$presence."' and lop='".$lop."'";
	}
	$i=1;
	$res = mysqli_query($con, $sql);
	while($row = mysqli_fetch_array($res)){ ?>
			<tr>
			<td><?php echo $i;?></td>
			<td><?php echo $row['ad_no']; ?></td>
			<td class="lalign"><?php echo $row['name']; ?></td>
			<td><?php echo $row['roll_no']; ?></td>
			<td><?php echo $row['dept']; ?></td>
			<td><?php echo $row['year']; ?></td>
			<td class="lalign"><?php if($row['event_1']=="NULL"){echo "Not Registered";} 
					  else{echo "Registered";}
			?></td>
			<td>
			<?php echo $row['attendance'];?>
			</td>
			<td class="lalign"><?php if($row['event_2']=="NULL"){echo "Not Registered";} 
					  else{echo "Registered";}
			?></td>
			<td>
			<?php echo $row['att_2'];?>
			</td>
			<td class="lalign"><?php if($row['event_3']=="NULL"){echo "Not Registered";} 
					  else{if($row['team_id1']==NULL){
						echo "No team";
							}
						else {echo $row['team_id1'];}
					  }
			?></td>
			<td>
			<?php echo $row['att_3'];?>
			</td>
			<td class="lalign"><?php if($row['event_4']=="NULL"){echo "Not Registered";} 
					  else{if($row['team_id2']==NULL){
						  echo "No Team";
					  }
						else{echo $row['team_id2'];}
					  }
			?></td>
			<td>
			<?php echo $row['att_4'];?>
			</td>
			<td><?php echo $row['lop']; ?></td>
			</tr>
<?php	$i++;}
}
}?>
</tbody>
</table>
</form>
<h3>Instructions for Add teammate
</body>
<script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script><script src='https://cdnjs.cloudflare.com/ajax/libs/jquery.tablesorter/2.28.14/js/jquery.tablesorter.min.js'></script>
<script >$(function () {
  $('#keywords').tablesorter();
});
//# sourceURL=pen.js
</script>
</html>