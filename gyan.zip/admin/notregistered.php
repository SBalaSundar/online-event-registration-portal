<?php
session_start();
if(!$_SESSION['aid']){
	echo "<script>alert('Un Authorized Access'); window.location.href='index.php';</script>";
}
else{
include 'connection.php';
?> 
<head>
<style class="cp-pen-styles">@import url('https://fonts.googleapis.com/css?family=Amarante');
html { overflow-y: scroll; }
body { 
  background: #eee url('https://i.imgur.com/eeQeRmk.png'); /* https://subtlepatterns.com/weave/ */
  font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
  font-size: 70%;
  line-height: 1;
  color: #585858;
  padding: 22px 10px;
  padding-bottom: 55px;
}

::selection { background: #5f74a0; color: #fff; }
::-moz-selection { background: #5f74a0; color: #fff; }
::-webkit-selection { background: #5f74a0; color: #fff; }

br { display: block; line-height: 1.6em; } 

article, aside, details, figcaption, figure, footer, header, hgroup, menu, nav, section { display: block; }
ol, ul { list-style: none; }

input, textarea { 
  -webkit-font-smoothing: antialiased;
  -webkit-text-size-adjust: 100%;
  -ms-text-size-adjust: 100%;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  outline: none; 
}

blockquote, q { quotes: none; }
blockquote:before, blockquote:after, q:before, q:after { content: ''; content: none; }
strong, b { font-weight: bold; } 

table { border-collapse: collapse; border-spacing: 0; }
img { border: 0; max-width: 100%; }

h1 { 
  font-family: 'Amarante', Tahoma, sans-serif;
  font-weight: bold;
  font-size: 3.6em;
  line-height: 1.7em;
  margin-bottom: 10px;
  text-align: center;
}


/** page structure **/
#wrapper {
  display: block;
  width: 850px;
  background: #fff;
  margin: 0 auto;
  padding: 10px 17px;
  -webkit-box-shadow: 2px 2px 3px -1px rgba(0,0,0,0.35);
}

#keywords {
  margin: 0 auto;
  font-size: 1.2em;
  margin-bottom: 15px;
}


#keywords thead {
  cursor: pointer;
  background: #c9dff0;
}
#keywords thead tr th { 
  font-weight: bold;
  padding: 10px 10px;
  padding-left: 10px;
}
#keywords thead tr th span { 
  padding-right: 20px;
  background-repeat: no-repeat;
  background-position: 100% 100%;
}

#keywords thead tr th.headerSortUp, #keywords thead tr th.headerSortDown {
  background: #acc8dd;
}

#keywords thead tr th.headerSortUp span {
  background-image: url('https://i.imgur.com/SP99ZPJ.png');
}
#keywords thead tr th.headerSortDown span {
  background-image: url('https://i.imgur.com/RkA9MBo.png');
}


#keywords tbody tr { 
  color: #555;
}
#keywords tbody tr td {
  text-align: center;
  padding: 15px 10px;
}
#keywords tbody tr td.lalign {
  text-align: left;
}</style>
</head>
<body bgcolor="aabbcc">
<p><h3>Admin Home Page</h3>
<a href="attendance.php">Attendance</a></p>
<form method="POST">
<!--<select name="viewcategory">
<option value="All">No Filters(Display all)</option>
<option value="dept">Department</option>
<option value="event">Event</option>
<option value="year">Year</option>
<option value="attendance">Presence</option>
<option value="lop">Level of Participation</option>
</select> !-->
	<table id="keywords" cellspacing="0" cellpadding="0" border="2">
	<thead>
		<th>S.No</th>
		<th>Ad_no</th>
		<th>Rollno</th>
		<th>Mailid</th>
		<th>Name</th>
		<th>Dept</th>
		<th>Year</th>
	</thead>
	<tbody>
<?php
	$sql = "select * from participants where event_1='NULL' and event_2='NULL' and event_3='NULL' and event_4='NULL'";
	$res = mysqli_query($con, $sql);
	$i=1;
	while($row = mysqli_fetch_array($res)){ ?>
			<tr>
			<td><?php echo $i;?></td>
			<td><?php echo $row['ad_no']; ?></td>
			<td><?php echo $row['roll_no']; ?></td>
			<td><?php echo $row['mailid'];?></td>
			<td class="lalign"><?php echo $row['name']; ?></td>
			<td><?php echo $row['dept']; ?></td>
			<td><?php echo $row['year']; ?></td>
			</tr>
<?php	$i++;}
} ?>
</tbody>
</table>
</form>
</body>
<script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script><script src='https://cdnjs.cloudflare.com/ajax/libs/jquery.tablesorter/2.28.14/js/jquery.tablesorter.min.js'></script>
<script >$(function () {
  $('#keywords').tablesorter();
});
//# sourceURL=pen.js
</script>
</html>