<?php
//http://localhost/main.php?email=$email_address&event_id=$event_id";
include 'connection.php';
//$dept = "CSE";
$dept = $_GET['q'];
//$event = "Poster Designing";
$event = $_GET['event'];
if($event == "Poster Designing"){
	$event="event_1";
	$event_name = "Poster Designing";
}
elseif($event == "Web Designing"){
	$event="event_2";
	$event_name = "Web Designing";
}
elseif($event == "Online Coding"){
	$event="event_3";
	$event_name = "Online Coding";
}
elseif($event == "DB Mania"){
	$event="event_4";
	$event_name = "DB Mania";
}
$sql = "select * from participants where dept='".$dept."' and ".$event."='".$event_name."'";
$res = mysqli_query($con, $sql);
?>
<table border="1">
	<thead>
		<th>Ad_no</th>
		<th>Name</th>
		<th>Rollno</th>
		<th>Dept</th>
		<th>Year</th>
		<th>Presence</th>
		<th>LOP</th>
	</thead>
	<tbody>
	<?php while($row = mysqli_fetch_array($res)){?>
		<tr>
			<td><?php echo $row['ad_no'];?></td>
			<td><?php echo $row['name'];?></td>
			<td><?php echo $row['roll_no'];?></td>
			<td><?php echo $row['dept'];?></td>
			<td><?php echo $row['year'];?></td>
			<td><?php echo $row['attendance'];?></td>
			<td><?php echo $row['lop'];?></td>
		</tr>
	<?php } ?>
	</tbody>
</table>