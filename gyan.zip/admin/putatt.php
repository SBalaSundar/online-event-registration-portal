<?php 	include 'connection.php';
		session_start();
		$event=$_SESSION['eventna'];
		$event_no =$_SESSION['eventnu'];
		if($event_no=='event_1'){$att = 'attendance';}
		elseif($event_no=='event_2'){$att = 'att_2';}
		elseif($event_no=='event_3'){$att = 'att_3';}
		elseif($event_no=='event_4'){$att = 'att_4';}
		$sql = "select * from participants where ".$event_no."='".$event."'";
		$res = mysqli_query($con, $sql);
		while($row = mysqli_fetch_array($res)){ 
			$button = $row['ad_no'];
			$val = $_POST[$button];
			$sql1 = "update participants set ".$att."='".$val."' where ad_no = '".$button."'";
			$res1 = mysqli_query($con, $sql1);
		}
		header('location:attendance.php');
?>