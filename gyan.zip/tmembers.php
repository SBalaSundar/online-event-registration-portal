<?php
echo '<input type="text" name="mem1"/>';
?>
	